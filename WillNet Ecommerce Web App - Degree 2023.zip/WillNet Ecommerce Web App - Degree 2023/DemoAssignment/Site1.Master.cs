﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoAssignment
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {



        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            //string searchText = HttpUtility.UrlEncode(search_text.Value.Trim());
            //Response.Redirect("~/ProductList.aspx?search=" + searchText);
        }


        protected void btnLogin_Click(object sender, EventArgs e)
        {

        }

        protected void btnSignUp_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void btnCart_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void btnLogin_Click1(object sender, ImageClickEventArgs e)
        {

        }

       
     

    }
}