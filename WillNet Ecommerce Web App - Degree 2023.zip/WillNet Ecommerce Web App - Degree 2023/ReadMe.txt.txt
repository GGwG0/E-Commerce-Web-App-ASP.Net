E-Commerce System

Developed By:

- Tan yen yee
- sharan
- wei han
- awie

Date 14/4/2023
Degree GUI Project

Built in admin account:[admin] username [admin] password
Built in customer account:[WEIHAN] username [.Awie0777] passwordw